import styles from "./table.module.scss";
import { Button } from "../button/button";
import { Input } from "../input/input";

class Table {
  #parentEle;
  #rowsData;
  #parentElementId;
  #addBookHandler;
  #actionHandler;
  #newBook = {
    id: 0,
    title: "",
    author: "",
  };

  handleActionClick(actionType, id) {
    this.#actionHandler(id, actionType);
  }

  handleAddbookClick() {
    if (!(this.#newBook.title.trim() || this.#newBook.author.trim())) return;
    this.#newBook.id = this.#rowsData.length + 1;
    this.#addBookHandler(this.#newBook);
  }

  handleTitleChanges(title) {
    this.#newBook.title = title;
  }

  handleAuthorChanges(author) {
    this.#newBook.author = author;
  }

  #populateActionColumn(row) {
    switch (row.action) {
      case "REQUEST_NEXT":
        return `
            ${new Button().render({
              id: "requestNext_" + row.id,
              label: "Request Next",
              clickHandler: this.handleActionClick.bind(
                this,
                row.action,
                row.id
              ),
              parentEle: this.#parentElementId,
            })}
          `;
      case "RETURN":
        return `
              ${new Button().render({
                id: "return_" + row.id,
                label: "Return",
                clickHandler: this.handleActionClick.bind(
                  this,
                  row.action,
                  row.id
                ),
                parentEle: this.#parentElementId,
              })}
            `;
      case "BORROW":
        return `
              ${new Button().render({
                id: "borrow_" + row.id,
                label: "Borrow",
                clickHandler: this.handleActionClick.bind(
                  this,
                  row.action,
                  row.id
                ),
                parentEle: this.#parentElementId,
              })}
            `;
      case "REQUEST_BY":
        return `Reqiuestted By User`;

      default:
        return `-`;
    }
  }

  #generateMarkup({ allowAdd }) {
    return `
        <table class="${styles["table-container"]}">
            <thead>
                <tr>
                    <td>Id</td>
                    <td>Title</td>
                    <td>Author</td>
                    <td>Lender</td>
                    <td>Borrower</td>
                    <td>Action</td>
                </tr>
            </thead>
            <tbody>
            ${this.#rowsData
              .map((row) => {
                return `
                  <tr>
                    <td>${row.id}</td>
                    <td>${row.title}</td>
                    <td>${row.author}</td>
                    <td>${row.lender}</td>
                    <td>${row.borrower}</td>
                    <td>${this.#populateActionColumn(row)}</td>
                  </tr>
                `;
              })
              .join("")}
              ${
                allowAdd &&
                `<tr>
                    <td>${this.#rowsData.length + 1}</td>
                    <td>${new Input().render({
                      id: "booktitle",
                      parentEle: this.#parentElementId,
                      inputChangeHandler: this.handleTitleChanges.bind(this),
                    })}</td>
                    <td>${new Input().render({
                      id: "bookauthor",
                      parentEle: this.#parentElementId,
                      inputChangeHandler: this.handleAuthorChanges.bind(this),
                    })}</td>
                    <td>-</td>
                    <td>-</td>
                    <td>${new Button().render({
                      parentEle: this.#parentElementId,
                      id: "addBook",
                      label: "Add Book",
                      clickHandler: this.handleAddbookClick.bind(this),
                    })}</td>
                  </tr>`
              }
            </tbody>
        </table>
    `;
  }

  #clear() {
    this.#parentEle.innerHTML = "";
  }

  render(props) {
    this.#parentEle = document.getElementById(props.parentEle);
    this.#parentElementId = props.parentEle;
    this.#rowsData = props.rows;
    this.#addBookHandler = props.addBookHandler;
    this.#actionHandler = props.actionHandler;
    this.#clear();
    const markup = this.#generateMarkup(props);
    return markup;
  }
}

export default new Table();
