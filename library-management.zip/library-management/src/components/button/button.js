import styles from "./button.module.scss";

export class Button {
  #parentEle;
  #clickHandler;
  #id;

  #addListener() {
    this.#parentEle.addEventListener("click", (event) => {
      const btn = event.target.closest(`#${this.#id}`);
      if (!btn) return;
      this.#clickHandler();
    });
  }

  #generateMarkup(id, label) {
    return `
        <button id="${id}" class="${styles["button"]}">${label}</button>
    `;
  }

  #clear() {
    this.#parentEle.innerHTML = "";
  }

  render({ id, label, parentEle, clickHandler }) {
    this.#parentEle = document.getElementById(parentEle);
    this.#clickHandler = clickHandler;
    this.#id = id;
    this.#clear();
    const markup = this.#generateMarkup(id, label);
    this.#addListener();
    return markup;
  }
}
