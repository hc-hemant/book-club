export class Input {
  #parentEle;
  #inputChangeHandler;
  #id;

  #addListener() {
    this.#parentEle.addEventListener("input", (event) => {
      const inputEle = event.target.closest(`#${this.#id}`);
      if (!inputEle) return;
      this.#inputChangeHandler(inputEle.value);
    });
  }

  #generateMarkup() {
    return `
        <input id="${this.#id}" class="input-box" type="text" />
    `;
  }

  #clear() {
    this.#parentEle.innerHTML = "";
  }

  render({ id, parentEle, inputChangeHandler }) {
    this.#parentEle = document.getElementById(parentEle);
    this.#inputChangeHandler = inputChangeHandler;
    this.#id = id;
    this.#clear();
    const markup = this.#generateMarkup();
    this.#addListener();
    return markup;
  }
}
