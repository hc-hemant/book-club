import Header from "./containers/header/header";
import Books from "./containers/books/books";

class App {
  init() {
    Header.render({ parentEle: "header" });
    Books.render({ parentEle: "main" });
  }
}

export default new App();
