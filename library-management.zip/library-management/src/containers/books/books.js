import table from "../../components/table/table";
import { getState, updateState } from "../../models/state";

class Books {
  #parentEle;
  #booksData;
  #parentElementId;
  #allowAdd;

  addBookHandler(payload) {
    updateState("ADD_BOOK", payload);
    this.render({ parentEle: this.#parentElementId });
  }

  actionHandler(id, action) {
    console.log(id, action);
  }

  #generateMarkup(parentElementId) {
    return `
        ${table.render({
          parentEle: parentElementId,
          rows: this.#booksData,
          allowAdd: true,
          addBookHandler: this.addBookHandler.bind(this),
          actionHandler: this.actionHandler.bind(this),
        })}
      `;
  }

  #clear() {
    this.#parentEle.innerHTML = "";
  }

  render({ parentEle }) {
    const state = getState((state) => state);
    this.#booksData = state.books;
    this.#allowAdd = state.username;
    this.#parentEle = document.getElementById(parentEle);
    this.#parentElementId = parentEle;
    this.#clear();
    const markup = this.#generateMarkup(parentEle);
    this.#parentEle.insertAdjacentHTML("afterbegin", markup);
  }
}

export default new Books();
