import { Input } from "../../components/input/input";
import { Button } from "../../components/button/button";
import { updateState } from "../../models/state";

class Header {
  #parentEle;
  userName;

  #inputHandler(text) {
    this.userName = text;
  }

  #clickHandler() {
    updateState("UPDATE_USER", this.userName);
  }

  #generateMarkup(parentElementId) {
    return `
        <p class="header-logo">Book club</p>
        <section>
          ${new Input().render({
            id: "username",
            parentEle: parentElementId,
            inputChangeHandler: this.#inputHandler.bind(this),
          })}
          ${new Button().render({
            parentEle: parentElementId,
            clickHandler: this.#clickHandler.bind(this),
            id: "headerSubmit",
            label: "Submit",
          })}
        </section>
      `;
  }

  #clear() {
    this.#parentEle.innerHTML = "";
  }

  render({ parentEle }) {
    this.#parentEle = document.getElementById(parentEle);
    this.#clear();
    const markup = this.#generateMarkup(parentEle);
    this.#parentEle.insertAdjacentHTML("afterbegin", markup);
  }
}

export default new Header();
