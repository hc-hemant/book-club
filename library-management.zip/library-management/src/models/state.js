let state = {
  username: "",
  books: [
    {
      id: 1,
      title: "Book1",
      author: "Author1",
      lender: "",
      borrower: "",
      action: "BORROW",
    },
    {
      id: 2,
      title: "Book2",
      author: "Author2",
      lender: "UserC",
      borrower: "UserB",
      action: "RETURN",
    },
    {
      id: 3,
      title: "Book3",
      author: "Author3",
      lender: "UserC",
      borrower: "UserB",
      action: "REQUEST_NEXT",
    },
    {
      id: 4,
      title: "Book4",
      author: "Author4",
      lender: "UserC",
      borrower: "UserB",
      action: "REQUESTED_BY",
    },
    {
      id: 5,
      title: "Book5",
      author: "Author5",
      lender: "UserC",
      borrower: "UserB",
      action: "BORROW",
    },
  ],
};

export const getState = (cb) => {
  return cb(state);
};

export const updateState = (action, payload) => {
  switch (action) {
    case "UPDATE_USER":
      state = {
        ...state,
        username: payload.username,
      };

    case "ADD_BOOK":
      state = {
        ...state,
        books: [
          ...state.books,
          {
            id: payload.id,
            title: payload.title,
            author: payload.author,
            lender: state.username,
            borrower: "-",
            action: "",
          },
        ],
      };
  }
};
