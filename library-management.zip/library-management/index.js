import "regenerator-runtime/runtime.js";
import "./style.scss";

import App from "./src/app";

App.init();
